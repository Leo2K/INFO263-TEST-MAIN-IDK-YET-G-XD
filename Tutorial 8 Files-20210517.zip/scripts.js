var convertToCurrency = "EUR";

function convertToFloat(input) {
    if (/^(\-|\+)?([0-9]+(\.[0-9]+)?|Infinity)$/
            .test(input))
        return Number(input);
    return NaN;
}