var superHero =
    {
      firstName: "Peter",
      lastName: "Parker",
      powers: ["Super Strength", "Wall climbing"],
    };

console.log(superHero.powers);

superHero["powers"].push("Web spinning");

console.log(superHero.powers);

superHero["alias"] = "Spiderman";
console.log(superHero.alias);
