var aPerson = {name: "Elon Musk", age: 34, degrees: "Software Engineering, Computer Science, Commerce and Space Exploration"};

console.log(aPerson);
console.log(`Hi, my name is ${aPerson.name}, I am ${aPerson.age} years old and I have the following degrees: ${aPerson.degrees}.`)

var betterPerson = {firstname: aPerson.name.split(" ")[0], lastname: aPerson.name.split(" ")[1], age: aPerson.age, degrees: aPerson.degrees.split(",")};

console.log(`Hello, my first name is ${betterPerson.firstname}. I also have a last name, it is ${betterPerson.lastname}. I am ${betterPerson.age} years old and I have these degrees: \n`);
for (i = 0; i < betterPerson.degrees.length; i++) {
    console.log(`${i+1}: ${betterPerson.degrees[i].trim()}`);
}
